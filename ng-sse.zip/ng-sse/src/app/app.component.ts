import { Component, OnInit, OnDestroy } from '@angular/core';
import { SseService } from './sse.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit, OnDestroy {
  title = 'ng-sse';
  messages = [];
  stream: Subscription;

  constructor(private sseService: SseService) { }

  ngOnInit() {
    this.stream = this.sseService
      .getServerSentEvent("http://localhost:3000/events")
      .subscribe(data => {
        this.messages.push(data.data)
      });
  }

  ngOnDestroy() {
    if (this.stream) {
      this.stream.unsubscribe();
    }
  }
}

